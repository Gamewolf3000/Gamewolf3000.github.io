self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "db482a01c24fc426d547cd3f352bb03e",
    "url": "./index.html"
  },
  {
    "revision": "db7a1034751e08580114",
    "url": "./static/js/2.4fe2b0f7.chunk.js"
  },
  {
    "revision": "0749163b59fbee32225059cb60c18af6",
    "url": "./static/js/2.4fe2b0f7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4cb50ca43e1a78876acd",
    "url": "./static/js/main.b860b57a.chunk.js"
  },
  {
    "revision": "5b5a91286a4b5d6873f6",
    "url": "./static/js/runtime-main.0aff8126.js"
  }
]);